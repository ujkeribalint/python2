

def elso_karakter(s):
    if s == "":
        return None
    return s[0]


def utolso_karakter(s):
    if s == "":
        return None
    return s[-1]



def legkisebb(lista):
    if lista == []:
        return None
    min_ertek = lista[0]
    for elem in lista:
        if elem < min_ertek:
            min_ertek = elem
    return min_ertek


def legnagyobb(lista):
    if lista == []:
        return None
    max_ertek = lista[0]
    for elem in lista:
        if elem > max_ertek:
            max_ertek = elem
    return max_ertek



def osszeg(lista):
    ossz = 0
    for elem in lista:
        ossz += elem
    return ossz


def szorzat(lista):
    szorz = 1
    for elem in lista:
        szorz *= elem
    return szorz



def parosok_szama(lista):
    db = 0
    for elem in lista:
        if elem % 2 == 0:
            db += 1
    return db


def paratlanok_szama(lista):
    db = 0
    for elem in lista:
        if elem % 2 != 0:
            db += 1
    return db


def pozitivok_szama(lista):
    db = 0
    for elem in lista:
        if elem > 0:
            db += 1
    return db


def negativok_szama(lista):
    db = 0
    for elem in lista:
        if elem < 0:
            db += 1
    return db



def benne_van_a_listaban(lista, keresett):
    for elem in lista:
        if elem == keresett:
            return True
    return False


def benne_van_a_stringben(szoveg, karakter):
    for ch in szoveg:
        if ch == karakter:
            return True
    return False



def kereses_a_listaban(lista, keresett):
    for i in range(len(lista)):
        if lista[i] == keresett:
            return i
    return None


def kereses_a_stringben(szoveg, karakter):
    for i in range(len(szoveg)):
        if szoveg[i] == karakter:
            return i
    return None



def parosok_kivalogatasa(lista):
    eredmeny = []
    for elem in lista:
        if elem % 2 == 0:
            eredmeny.append(elem)
    return eredmeny


def paratlanok_kivalogatasa(lista):
    eredmeny = []
    for elem in lista:
        if elem % 2 != 0:
            eredmeny.append(elem)
    return eredmeny


def pozitivok_kivalogatasa(lista):
    eredmeny = []
    for elem in lista:
        if elem > 0:
            eredmeny.append(elem)
    return eredmeny


def negativok_kivalogatasa(lista):
    eredmeny = []
    for elem in lista:
        if elem < 0:
            eredmeny.append(elem)
    return eredmeny



def lista_atlag(lista):
    if lista == []:
        return 0
    return osszeg(lista) / len(lista)



def faktorialis(n):
    if n < 0:
        return None
    eredmeny = 1
    for i in range(1, n + 1):
        eredmeny *= i
    return eredmeny


